document.addEventListener('DOMContentLoaded', () => {

    // --- 1. REFERENCIAS A ELEMENTOS ---
    const tabla = document.querySelector('.table-container table');
    let tbody = tabla.querySelector('tbody');
    if (!tbody) {
        tbody = document.createElement('tbody');
        tabla.appendChild(tbody);
    }

    // Referencias del Modal
    const btnNuevoEstudiante = document.querySelector('.list-header .btn-primary');
    const modal = document.getElementById('modal-nuevo');
    const formNuevoEstudiante = document.getElementById('form-nuevo-estudiante');
    const btnCerrarModal = document.getElementById('btn-cerrar-modal');
    const btnCancelarModal = document.getElementById('btn-cancelar-modal');
    const modalError = document.getElementById('modal-error');


    // --- 2. FUNCIONES DE CARGA DE TABLA ---
    async function cargarEstudiantes() {
        try {
            const response = await fetch('/api/estudiantes');
            if (response.status === 401 || response.status === 403) {
                window.location.href = '/login';
                return;
            }
            if (!response.ok) {
                throw new Error('Error al obtener los datos');
            }
            const estudiantes = await response.json();
            renderTabla(estudiantes);
        } catch (error) {
            console.error('Error en cargarEstudiantes:', error);
            tbody.innerHTML = `<tr><td colspan="7">Error al cargar datos. Intente recargar.</td></tr>`;
        }
    }

    /**
     * CORREGIDO: Esta función ahora coincide con las 7 columnas de tu HTML
     * (RUT, Nombre, Apellido, Correo, Carrera, Teléfono, Acciones)
     */
    function renderTabla(estudiantes) {
        tbody.innerHTML = '';
        if (estudiantes.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7">No hay estudiantes registrados.</td></tr>`;
            return;
        }

        estudiantes.forEach(est => {
            const tr = document.createElement('tr');

            // Usamos (est.ttu_car || '') para que muestre un guion o vacío
            // en lugar de 'null' si el dato no existe.
            tr.innerHTML = `
            <td>${est.ttu_rut}</td>
            <td>${est.ttu_nom}</td>
            <td>${est.ttu_ape}</td>
            <td>${est.ttu_cor}</td>
            <td>${est.ttu_carr || ''}</td> <td>${est.ttu_tel || ''}</td> <td>
                <button class="btn-accion btn-editar" data-id="${est.ttu_id_usr}">
                    <i class="fa-solid fa-pencil"></i>
                </button>
                <button class="btn-accion btn-eliminar" data-id="${est.ttu_id_usr}">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </td>
        `;
            tbody.appendChild(tr);
        });
    }

    // --- 3. FUNCIONES DEL MODAL ---
    function mostrarModal() {
        formNuevoEstudiante.reset(); // Limpia el formulario
        modalError.textContent = ''; // Limpia errores previos
        modalError.style.display = 'none';
        modal.classList.remove('hidden');
    }

    function ocultarModal() {
        modal.classList.add('hidden');
    }

    // --- 4. MANEJADOR DEL SUBMIT DEL FORMULARIO ---
    async function handleFormSubmit(e) {
        e.preventDefault(); // Evita que la página se recargue

        const submitButton = formNuevoEstudiante.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Guardando...';
        modalError.style.display = 'none';

        // 1. Obtener datos del formulario
        const formData = new FormData(formNuevoEstudiante);
        // Convertimos los datos del formulario a un objeto JSON
        const data = Object.fromEntries(formData.entries());

        try {
            // 2. Enviar datos a la API (POST /api/estudiantes)
            const response = await fetch('/api/estudiantes', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (!response.ok) {
                // Si la API devuelve un error (ej: RUT duplicado), lo mostramos
                throw new Error(result.message || 'Error al crear el estudiante');
            }

            // 3. ¡Éxito!
            ocultarModal();       // Ocultamos el modal
            cargarEstudiantes(); // Recargamos la tabla con el nuevo estudiante

        } catch (error) {
            // 4. Mostrar error en el modal
            modalError.textContent = error.message;
            modalError.style.display = 'block';
        } finally {
            // Reactivar el botón
            submitButton.disabled = false;
            submitButton.textContent = 'Guardar Estudiante';
        }
    }


    // --- 5. EVENT LISTENERS ---

    // Carga inicial de la tabla
    cargarEstudiantes();

    // Listeners para abrir y cerrar el modal
    btnNuevoEstudiante.addEventListener('click', mostrarModal);
    btnCerrarModal.addEventListener('click', ocultarModal);
    btnCancelarModal.addEventListener('click', ocultarModal);

    // Listener para el overlay (cerrar al hacer clic afuera)
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            ocultarModal();
        }
    });

    // Listener para enviar el formulario
    formNuevoEstudiante.addEventListener('submit', handleFormSubmit);

});