// Espera a que el HTML esté cargado
document.addEventListener('DOMContentLoaded', () => {

    const loginForm = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message')
    const rutInput = document.getElementById('login-rut'); // Es buena idea guardar los inputs también
    const passwordInput = document.getElementById('login-password');

    // Escuchamos el evento 'submit' del formulario
    loginForm.addEventListener('submit', async (event) => {

        // Evitamos que el formulario se envíe de forma tradicional
        event.preventDefault();

        errorMessage.textContent = ''; // Limpiamos errores

        // Obtenemos los datos del formulario
        const rut = rutInput.value.trim();
        const password = passwordInput.value.trim();

        // Validación de campos vacíos
        if (rut === '' || password === '') {
            errorMessage.textContent = 'Por favor, completa todos los campos.';
            return; // Detiene el envío
        }

        // Enviamos los datos al SERVIDOR usando 'fetch' 
        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                // Ahora enviamos los valores "limpios" (sin espacios)
                body: JSON.stringify({ rut, password }),
            });

            // Leemos la respuesta JSON del servidor
            const data = await response.json();

            if (response.ok) { // Si el status es 2xx (ej. 200)
                if (data.success) {
                    // ¡Éxito! Redirigimos al dashboard
                    window.location.href = '/dashboardAdmin';
                }
            } else {
                // Si el status es 4xx o 5xx (ej. 401 No autorizado)
                errorMessage.textContent = data.message || 'Error desconocido';
            }

        } catch (error) {
            // Error de red (ej. servidor caído)
            console.error('Error de red:', error);
            errorMessage.textContent = 'No se puede conectar al servidor.';
        }
    });
});