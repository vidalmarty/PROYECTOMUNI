const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const pool = require('../config/db');

// ----- RUTA DE LOGIN (POST /login) -----
router.post('/login', async (req, res) => {
    const { rut, password } = req.body;

    if (!rut || !password) {
        return res.status(400).json({ success: false, message: 'Faltan RUT o contraseña' });
    }

    try {
        // Obtenemos el ROL junto con los demás datos
        const query = 'SELECT * FROM tab_usr WHERE ttu_rut = $1';
        const result = await pool.query(query, [rut]);

        if (result.rows.length === 0) {
            return res.status(401).json({ success: false, message: 'RUT o contraseña incorrectos' });
        }

        const user = result.rows[0];
        const passwordMatch = await bcrypt.compare(password, user.ttu_con);

        if (passwordMatch) {
            // Guardamos el ID, RUT y ROL en la sesión
            req.session.user = {
                id: user.ttu_id_usr,
                rut: user.ttu_rut,
                role: user.ttu_rol // ¡Importante!
            };

            // Determinamos a dónde redirigir según el rol
            let redirectUrl;
            if (user.ttu_rol === 'administrador') {
                redirectUrl = '/dashboardAdmin';
            } else if (user.ttu_rol === 'estudiante') {
                redirectUrl = '/dashboardEst'; // Asumiendo que tienes esta ruta
            } else {
                // Rol desconocido o no permitido para login
                return res.status(403).json({ success: false, message: 'Rol no autorizado para iniciar sesión.' });
            }

            // Enviamos la URL de redirección al frontend
            res.json({ success: true, redirect: redirectUrl });

        } else {
            res.status(401).json({ success: false, message: 'RUT o contraseña incorrectos' });
        }
    } catch (error) {
        console.error('Error en /login:', error);
        res.status(500).json({ success: false, message: 'Error interno del servidor' });
    }
});

// ----- RUTA DE LOGOUT (GET /logout) -----
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('No se pudo cerrar sesión.');
        }
        res.redirect('/');
    });
});

module.exports = router;