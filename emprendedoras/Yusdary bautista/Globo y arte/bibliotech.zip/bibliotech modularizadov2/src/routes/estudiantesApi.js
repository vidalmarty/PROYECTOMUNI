const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const pool = require('../config/db'); // Importas tu pool de conexión
const { isAuthenticated, isAdmin } = require('../middleware/authMiddleware');

// Aseguramos TODAS las rutas de este archivo
router.use(isAuthenticated);
router.use(isAdmin);

// --- API CRUD PARA ESTUDIANTES (tabla tab_usr) ---

/**
 * @route   GET /api/estudiantes
 * @desc    Obtener TODOS los estudiantes
 */
router.get('/estudiantes', async (req, res) => {
    try {
        // AÑADIMOS ttu_car y ttu_tel AL SELECT
        const query = "SELECT ttu_id_usr, ttu_rut, ttu_nom, ttu_ape, ttu_cor, ttu_carr, ttu_tel FROM tab_usr WHERE ttu_rol = 'estudiante' ORDER BY ttu_ape";
        const result = await pool.query(query);
        res.json(result.rows);
    } catch (error) {
        console.error('Error en GET /api/estudiantes:', error);
        res.status(500).json({ success: false, message: 'Error interno del servidor' });
    }
});

/**
 * @route   POST /api/estudiantes
 * @desc    Crear un NUEVO estudiante
 */
router.post('/estudiantes', async (req, res) => {
    // 1. Obtenemos los datos (los nuevos son opcionales)
    const { rut, nombre, apellido, correo, password } = req.body;
    const carrera = req.body.carrera || null; // Si no viene, guarda NULL
    const telefono = req.body.telefono || null; // Si no viene, guarda NULL

    if (!rut || !nombre || !apellido || !correo || !password) {
        return res.status(400).json({ success: false, message: 'Faltan datos obligatorios' });
    }

    try {
        // 2. Hashear la contraseña
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);

        // 3. AÑADIMOS las nuevas columnas al INSERT
        const query = `
            INSERT INTO tab_usr (ttu_rut, ttu_nom, ttu_ape, ttu_cor, ttu_con, ttu_rol, ttu_carr, ttu_tel)
            VALUES ($1, $2, $3, $4, $5, 'estudiante', $6, $7)
            RETURNING ttu_id_usr, ttu_rut, ttu_nom, ttu_ape, ttu_cor, ttu_carr, ttu_tel;
        `;

        // 4. AÑADIMOS las nuevas variables a los parámetros
        const result = await pool.query(query, [rut, nombre, apellido, correo, hash, carrera, telefono]);

        res.status(201).json({ success: true, message: 'Estudiante creado', data: result.rows[0] });

    } catch (error) {
        console.error('Error en POST /api/estudiantes:', error);
        if (error.code === '23505') {
            return res.status(400).json({ success: false, message: 'El RUT o Correo ya está registrado' });
        }
        res.status(500).json({ success: false, message: 'Error interno del servidor' });
    }
});

// (Aquí puedes agregar las rutas PUT para actualizar y DELETE para borrar más adelante)

module.exports = router;