const express = require('express');
const path = require('path');
const router = express.Router();

// Importamos los middlewares de seguridad
const { isAuthenticated, isAdmin } = require('../middleware/authMiddleware');

// ----- RUTA RAÍZ (GET /) -----
router.get('/', (req, res) => {
    res.redirect('/login');
});

// ----- RUTA LOGIN (GET /login) -----
router.get('/login', (req, res) => {
    if (req.session.user) {
        // Redirigir según el rol si ya está logueado
        if (req.session.user.role === 'administrador') {
            return res.redirect('/dashboardAdmin');
        } else if (req.session.user.role === 'estudiante') {
            return res.redirect('/dashboardEst');
        }
    }
    res.sendFile(path.join(__dirname, '../../public/login/login.html'));
});

// ----- RUTA DASHBOARD ADMIN (GET /dashboardAdmin) -----
// Protegida: debe estar logueado Y ser admin
router.get('/dashboardAdmin', [isAuthenticated, isAdmin], (req, res) => {
    res.sendFile(path.join(__dirname, '../../public/dashboardAdmin/dashboardAdmin.html'));
});

// ----- RUTA CRUD ESTUDIANTES (GET /crudEstudiantes) -----
// Protegida: debe estar logueado Y ser admin
router.get('/crudEstudiantes', [isAuthenticated, isAdmin], (req, res) => {
    res.sendFile(path.join(__dirname, '../../public/CRUDestudiantes/CRUDestudiantes.html'));
});

// (Aquí podrías agregar la ruta para el dashboard de estudiante, solo con 'isAuthenticated')

module.exports = router;