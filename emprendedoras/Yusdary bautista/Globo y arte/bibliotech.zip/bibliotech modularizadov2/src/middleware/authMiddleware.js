// Middleware para verificar si el usuario está autenticado
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next(); // El usuario está logueado, continuar
    }

    // Si es una API, devolvemos JSON
    if (req.originalUrl.startsWith('/api/')) {
        return res.status(401).json({ success: false, message: 'No autorizado' });
    }

    // Si es una página, redirigimos al login
    res.redirect('/login');
}

// Middleware para verificar si el usuario es Administrador
// ¡Usar SIEMPRE DESPUÉS de isAuthenticated!
function isAdmin(req, res, next) {
    if (req.session.user && req.session.user.role === 'administrador') {
        return next(); // El usuario es admin, continuar
    }

    // Si es una API, devolvemos JSON
    if (req.originalUrl.startsWith('/api/')) {
        return res.status(403).json({ success: false, message: 'Acceso denegado. Requiere rol de administrador.' });
    }

    // Si es una página, redirigimos al login
    res.redirect('/login');
}

module.exports = { isAuthenticated, isAdmin };