const path = require('path');

// 1. ¡IMPORTANTE! Cargar .env PRIMERO
// Le decimos que busque el .env "subiendo un nivel" (../)
require('dotenv').config({ path: path.join(__dirname, '../.env') });

// 2. Importar nuestra app configurada
const app = require('./app');

// 3. Definir el puerto
const port = process.env.PORT || 3000;

// 4. Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor "modularizado" corriendo en http://localhost:${port}`);
});