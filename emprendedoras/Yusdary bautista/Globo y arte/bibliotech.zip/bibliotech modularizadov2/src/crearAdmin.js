const { Pool } = require('pg');
const bcrypt = require('bcrypt');

// Configura tu conexión
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    password: 'novoa',
    database: 'bibliotech_test1',
    port: 5432,
});

async function crearUsuario() {
    // DEFINE TU USUARIO DE PRUEBA
    // ¡Recuerda exactamente estos datos!
    const rut = '11.111.111-1';
    const passwordPlano = 'clave123';

    // Datos de relleno para las columnas NOT NULL
    const nombre = 'Usuario';
    const apellido = 'De Prueba';
    const correo = 'prueba@correo.com';
    const rol = 'administrador';

    try {
        console.log('Hasheando contraseña...');
        const saltRounds = 10;
        const passwordHash = await bcrypt.hash(passwordPlano, saltRounds);
        console.log('¡Hash creado!');

        // 3. USA EL INSERT CORRECTO para 'tab_usr'
        const query = `
            INSERT INTO tab_usr 
                (ttu_rut, ttu_con, ttu_nom, ttu_ape, ttu_cor, ttu_rol) 
            VALUES 
                ($1, $2, $3, $4, $5, $6) 
            RETURNING ttu_id_usr, ttu_rut;
        `;

        const res = await pool.query(query, [
            rut,
            passwordHash,
            nombre,
            apellido,
            correo,
            rol
        ]);

        console.log('¡Usuario creado con éxito en tab_usr!');
        console.log(res.rows[0]);

    } catch (error) {
        console.error('Error creando usuario:', error);
    }
    pool.end();
}

crearUsuario();