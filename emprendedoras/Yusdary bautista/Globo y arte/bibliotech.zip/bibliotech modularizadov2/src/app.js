const express = require('express');
const session = require('express-session');
const path = require('path');

// Importamos nuestros routers
const viewsRoutes = require('./routes/views');
const authRoutes = require('./routes/auth');
const estudiantesApiRoutes = require('./routes/estudiantesApi');

// 1. INICIALIZACIÓN
const app = express();

// 2. MIDDLEWARES GLOBALES

// Servir archivos estáticos (public)
app.use(express.static(path.join(__dirname, '../public')));

// Entender JSON
app.use(express.json());

// Configurar Sesión
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Poner 'true' si usas HTTPS
}));

// 3. USAR RUTAS
// Le decimos a Express que use los routers que importamos
app.use(viewsRoutes); // Rutas de vistas (/, /login, /dashboard)
app.use(authRoutes);  // Rutas de API (POST /login, GET /logout)
app.use('/api', estudiantesApiRoutes); // Rutas de API para estudiantes (prefijo /api)

// 4. EXPORTAR LA APP
module.exports = app;